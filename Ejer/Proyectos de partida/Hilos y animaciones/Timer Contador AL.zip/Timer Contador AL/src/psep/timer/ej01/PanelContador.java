package psep.timer.ej01;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.Timer;

public class PanelContador extends JPanel
{
	public final static int ANCHO = 400; // ancho del panel
	public final static int ALTO = 300; // alto del panel
	private final static int DELAY = 500; // retardo del timer, cada cuánto
											// genera un evento ActionEvent
	private final static int POS_X = ANCHO / 3; // posición x del contador
	private final static int POS_Y = ALTO / 3; // posición y del contador
	private int x;
	private int y;
	private int contador;
	private Timer timer;

	/**
	 * Constructor
	 */
	public PanelContador()
	{
		this.setBackground(Color.black);
		this.setPreferredSize(new Dimension(ANCHO, ALTO));
		x = POS_X;
		y = POS_Y;
		contador = 0;
		// a completar

	}

	/**
     *   
     *       
     */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		// a completar

	}

	public void mousePressed(MouseEvent e)
	{
	};

	public void mouseReleased(MouseEvent e)
	{
	};

	public void mouseClicked(MouseEvent e)
	{
		// a completar

	};

	public void mouseEntered(MouseEvent e)
	{
	};

	public void mouseExited(MouseEvent e)
	{
	};

}
