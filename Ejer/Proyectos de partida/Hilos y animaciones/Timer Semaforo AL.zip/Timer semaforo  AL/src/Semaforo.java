import java.awt.Color;
/**
 * Modela un Semaforo  
 *  
 */
public class Semaforo
{

    private Color c;

    /**
     * Constructor de la clase Semaforo
     */
    public Semaforo()
    {
        c = Color.red;
    }

    /**
     *  
     * Obtener el color del semáforo
     */
    public Color getColor()
    {
        return c;
    }

    /**
     * 
     *  Actualizar color del semaforo
     */
    public void avanzar()
    {
        
    	
    	
    	

    }
 

    /**
     * 
     *  Cambiar el color   
     */
    public void setColor(Color c)
    {
        this.c = c;
    }
    
    /**
     *   
     */
    public String toString()
    {
        return c.toString();
    }
    
}
