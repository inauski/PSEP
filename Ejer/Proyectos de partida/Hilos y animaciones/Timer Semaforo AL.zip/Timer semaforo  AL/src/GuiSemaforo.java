
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
 

public class GuiSemaforo  extends JFrame
{
    private JButton btnIniciarParar;
    
    private PanelSemaforo  panelSemaforo;
    private Semaforo semaforo; // el modelo

    /**
     * Constructor  
     */
    public GuiSemaforo()
    {
        this.semaforo = new Semaforo();
        crearGui();
        mostrarGui();

    }

    /**
     *   
     */
    private void crearGui()
    {
        this.setTitle("Uso de un timer para simular  un sem�foro ");
        JPanel pnlSur = new JPanel();
        pnlSur.setBorder(new TitledBorder("Iniciar Semaforo / Parar Sem�foro"));

        btnIniciarParar = new JButton("Iniciar");
      
        pnlSur.add(btnIniciarParar);
        this.add(pnlSur, BorderLayout.SOUTH);

        panelSemaforo = new PanelSemaforo();
        this.add(panelSemaforo, BorderLayout.CENTER);
        btnIniciarParar.addActionListener(panelSemaforo);

        

    }

    /**
     *   
     */
    private void mostrarGui()
    {

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(400, 400);
        this.setLocationRelativeTo(null);
        this.setResizable(true);
        this.setVisible(true);
    }

    /**
     * el panel es una clase interna
     */

    private class PanelSemaforo extends JPanel  
    {
        private final int DELAY = 400;
        private Timer timer; 

       
        /**
         * Constructor 
         */
        public PanelSemaforo()
        {
        	// a completar
            setBackground(Color.black); 
        	
        	

        }
        /**
         *  
         * Se ejecuta cada vez que el panel necesita ser dibujado
         *      
         */
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);
            // a completar
            
            
            
            
            
            
        }
     
     
        /**
         *  este método se ejecutará cuando el timer genere un evento y cuando se haga
         *  click en el botón de inicio y en el de parada
         */
        public void actionPerformed(ActionEvent ev)
		{
        	// a completar
        	
        	
        	
        	
			
		}
        
        
        
        

    }
    
    public static void main(String[] args)
    {
        new GuiSemaforo();
 
    }
}