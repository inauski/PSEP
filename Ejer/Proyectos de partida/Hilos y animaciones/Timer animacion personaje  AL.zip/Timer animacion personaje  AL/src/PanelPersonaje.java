import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;


public class PanelPersonaje extends JPanel   
{ 
    private static final int POSX = 30; //posici�n inicial x de la imagen
    private static final int POSY = 130; //posici�n inicial y de la imagen
    private  ImageIcon imagenes[]; // el array que guardar� las im�genes de la secuencia animada
    private static final int NUM_FRAMES = 5; // n� im�genes a mostrar
    private int imagenActual = 0;    // imagen actual a mostrar
    private static int DELAY = 100;   // intervalo del timer  

    private JButton btnIniciar;
    private JButton btnParar;

    private Timer timer;
    private int x;  // coordenadas x e y donde se sit� la secuencia animada
    private int y;
    

    /**
     * Constructor 
     */
    public PanelPersonaje()
    {
    	setBackground(Color.white);   
        btnIniciar = new JButton("Iniciar");
        add(btnIniciar);
        btnIniciar.addActionListener(this);
        btnParar = new JButton("Parar");
        add(btnParar);     
        btnParar.addActionListener(this);
        timer = new Timer(DELAY, this);
        x = POSX;
        y = POSY;
        
        // a completar
        
       
       

    }
    
    /**
     *  
     * Se ejecuta cada vez que el panel necesita ser dibujado
     *      
     */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
      
        // a completar
        
        
    }


    /**
     * 
     */
    public void actionPerformed(ActionEvent ev)
    {
    	 // a completar
    	
    	
    }

    /**
     * actualizar la coordenada x en la que se mostrar� la imagen
     * incrementar en 1 la posici�n de la imagen a mostrar del array de im�genes
     */
    private  void actualizar()
    {
    	 // a completar
    	
    	
    }

    /**
     * se inicia el timer si est� parado
     */
    private  void iniciarAnimacion()
    {
    	 // a completar
    	
    	
    }

    /**
     * se para el timer si   est� funcionando
     */
    private  void pararAnimacion()
    {
    	 // a completar
    	
    	
    }

}