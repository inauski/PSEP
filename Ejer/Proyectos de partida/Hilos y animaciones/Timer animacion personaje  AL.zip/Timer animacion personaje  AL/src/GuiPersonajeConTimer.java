import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;


public class GuiPersonajeConTimer extends JFrame
{

	private PanelPersonaje panel;

	/**
	 * Constructor
	 */
	public GuiPersonajeConTimer()
	{
		crearGui();
		mostrarGui();

	}

	/**
     *   
     */
	private void crearGui()
	{
		this.setTitle("Mostrar una secuencia animada de im�genes con Timer ");
		JPanel pnlNorte = new JPanel();
		pnlNorte.setBorder(new TitledBorder("Iniciar   / parar  "));

		this.add(pnlNorte, BorderLayout.NORTH);

		panel = new PanelPersonaje();
		this.add(panel, BorderLayout.CENTER);

	}

	/**
     *   
     */
	private void mostrarGui()
	{

		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(400, 300);
		this.setLocationRelativeTo(null);
		this.setResizable(true);
		this.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		/*
		 * SwingUtilities.invokeLater(new Runnable() { public void run() { new
		 * GuiPersonajeConTimer(); } } );
		 */

		new GuiPersonajeConTimer();

	}
}