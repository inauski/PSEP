

public class HiloConsumidor extends Thread
{
	private Buffer buffer;
	
	/*
	 * Constructor
	 */
	public HiloConsumidor(Buffer buffer)
	{
		this.buffer = buffer;
		this.setName("Thread consumidor ");
	
	}
	
	public void run()
	{
		for(int i=1; i <= 10;i++)
		{
			buffer.borrar();
		
			try
			{
				Thread.sleep(300);
			}
			catch (InterruptedException ex){}
		}
		
		
	}

}
