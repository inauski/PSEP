import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Recurso compartido - Debe utilizarse en exclusi�n mutua. Los hilos
 * consumidores acceder�n a �l para tomar un elemento, el hilo productor para
 * a�adir un elemento
 * 
 */
public class Buffer 
{
	private final int TAM = 10; // el tama�o m�ximo de la lista, el n� m�ximo de
	// elementos que se podr�n a�adir a ella
	private List<Integer> lista;

	public Buffer()
	{
		lista = new ArrayList<Integer>();
	}

	/**
	 * 
	 * a�adir un valor a la lista
	 * si la lista est� llena el productor  deber� esperar
	 * Despu�s de a�adir un valor se escribe el nombre del hilo y el valor a�adido
	 * y se avisa a los hilos que est�n esperando
	 * @throws InterruptedException 
	 */
	
	//Metodo synchronized para que solo un hilo lo ejecute cada vez. Si ponemos las clases HiloConsumidor e HiloProductor 
	//extendidas de Thread, no hace falta aqui lanzar la excepcion de interrupcion (throws InterruptedException)
	public synchronized  void insertar(int valor) 
	{
		 
		try
		{
			while(lista.size() == TAM)//mientras el objeto este lleno, espera
                wait();    // Si pusiesemos Thread.yield(), se produciria el abrazo mortal ya que el hilo no libera el lock
				
		}
		catch (InterruptedException ex) {}
		
		lista.add(valor); //a�adimos el valor a la lista
		
		System.out.println(Thread.currentThread().getName() + "A�adido valor: " +  valor);
		
		notifyAll(); //notifica que no est� lleno
	}

	/**
	 * 
	 * borrar un valor de la lista (siempre el primero)
	 * si la lista est� vac�a el consumidor deber� esperar
	 * Despu�s de borrar un valor se escribe el nombre del hilo y el valor borrado
	 * y se avisa a los hilos que est�n esperando
	 * @throws InterruptedException 
	 */
	
	//Metodo synchronized para que solo un hilo lo ejecute cada vez.
	public synchronized   void borrar() 
	{
		try
        {
            while (lista.size() == 0) //Mientras la lista sea 0(vacia), espera
                wait(); // Si pusiesemos Thread.yield() se produciria el abrazo mortal ya que el hilo no libera el lock
        }
        catch (InterruptedException ex) { }       
      
	 
        System.out.println(Thread.currentThread().getName()+" Consumido Valor "+lista.remove(0));
        
        notifyAll();//notifica que no esta lleno
        
        //Otra forma
//		 if (lista.size() == 0)
//			wait();
//		 int valor = lista.get(0);
//		 lista.remove(0);
//		 System.out.println(Thread.currentThread().getName() + valor);
//		 notifyAll();
		 
	}

}
