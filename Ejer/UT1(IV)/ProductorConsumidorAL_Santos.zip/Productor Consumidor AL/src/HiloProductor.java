import java.util.Random;

public class HiloProductor extends Thread 
{

	private Buffer buffer;
	private Random aleatorio;
	
	/*
	 * Constructor
	 */
	public HiloProductor(Buffer buffer)
	{
	
		this.buffer = buffer;
		this.setName("Thread productor ");
		aleatorio = new Random();
		
	}
	
	public void run()
	{
		
		for (int i = 1; i <= 20; i++) 
		{
			int numero=aleatorio.nextInt(70); 
			buffer.insertar(numero);   
			
			try 
			{
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	
	}
}

