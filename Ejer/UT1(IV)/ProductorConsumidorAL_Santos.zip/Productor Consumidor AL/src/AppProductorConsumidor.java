
public class AppProductorConsumidor {

	public static void main(String[] args) {
		
		//Creamos un buffer, que van a compartir
		Buffer buffer = new Buffer();  
		
		//Creamos los hilos, un productor y dos consumidores, que comparten el mismo buffer
		HiloProductor productor = new HiloProductor(buffer);
		HiloConsumidor consumidor = new HiloConsumidor(buffer);
		HiloConsumidor consumidor2 = new HiloConsumidor(buffer);
        
		//Iniciamos los hilos
		productor.start();
		consumidor.start();
		consumidor2.start();
	}

}
