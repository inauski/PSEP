

/**
*   Aqu� se crea la cuenta compartida y dos hilos, uno que ingresa y otro
*   que saca. Se ingresa  100�  y se saca  50�.
*   Esperamos a que los hilos terminen y mostramos el balance de la cuenta
*    
*/
public class TestCuenta 
{
   
   public static void main(String[] args) throws InterruptedException
   {
	   //Creamos el recuros compartido
       CuentaBancaria cuentaCompartida = new CuentaBancaria();
	   
       //Creamos los hilos deposito y reintegro
       Thread hiloDep =new HiloDeposito(cuentaCompartida,100);
       Thread hiloReint =new HiloReintegro(cuentaCompartida,50);
	   
       //Inicio de hilos
       hiloDep.start();
	   hiloReint.start();
	   
	   //Esperan a que todos los hilos terminen
	   hiloDep.join();
	   hiloReint.join();
	   
	   //Importe final de la cuenta
	   System.out.println("La cuenta tiene un saldo de: "+ cuentaCompartida.getBalance()+"�");
	   
      
        
   }
}

