/**
 * Cuenta bancaria con un balance que puede ser modificado con ingresos y
 * reintegros - es el recurso que se comparte Este objeto se utilziar� en
 * exclusi�n mututa y adem�s los hilos que lo utilicen se coordinar�n de tal
 * forma que un hilo que quiere sacar de la cuenta dinero no lo pueda hacer si
 * �sta est� vac�a
 */
public class CuentaBancaria
{
	private double balance;

	/**
	 * Constructor
	 */
	public CuentaBancaria()
	{
		balance = 0;
	}

	/**
	 * depositar dinero en la cuenta
	 * siempre se puede a�adir a la cuenta dinero
	 * no hay ninguna condici�n que haya que cumplir
	 * para que un hilo pueda ejecutar este c�digo
	 * cuando se a�ade se avisa a los hilos que esperan para poder sacar
	 * 
	 * Muestra mensajes que indiquen la cantidad que se deposita y el nuevo balance
	 * @param cantidad la cantidad a ingresar
	 */
	//Ponemos el metodo como synchronized para que solo un hilo lo ejecute 
	public synchronized  void depositar(double cantidad)
	{
		balance += cantidad;
			notifyAll();//notifica que hay dinero
		System.out.println("Cantidad depositada: " + cantidad + " .Nuevo balance: "+ balance +  "�");
		 
		

	}

	/**
	 * reintegrar dinero de la cuenta
	 * no se puede sacar de la cuenta si hay menos dinero del que se
	 * quiere reintegrar. Si ocurre esto el hilo que intenta ejecutar el c�digo
	 * tendr� que esperar
	 *  Muestra mensajes que indiquen la cantidad que se saca y el nuevo balance
	 * 
	 * @param cantidad la cantidad a reintegrar
	 */
	//Ponemos el metodo como synchronized para que solo un hilo lo ejecute. Reintegra la cantidad en el balance mientras sea mayor (que el balance)
	public synchronized  void reintegrar(double cantidad)
	{ 
		while (balance < cantidad)
			try
		{
			wait();//espera a que haya dinero
		}
		catch (InterruptedException e){}
		
		balance -=cantidad;
			notifyAll();//notifica que hay dinero
		System.out .println("Se ha sacado: "+ cantidad +" .El nuevo balance es de: " +balance + "�");
		
		

	}

	/**
	 * @return devuelve el balance actual de la cuenta
	 */
	//Ponemos el metodo como synchronized para que solo un hilo lo ejecute.
	public  synchronized  double getBalance()
	{
		return balance;
	}

}