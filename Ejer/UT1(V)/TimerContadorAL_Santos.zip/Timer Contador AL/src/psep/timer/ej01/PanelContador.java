package psep.timer.ej01;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;
import javax.swing.Timer;

public class PanelContador extends JPanel implements ActionListener,
MouseListener, KeyListener
{
	public final static int ANCHO = 400; // ancho del panel
	public final static int ALTO = 300; // alto del panel
	private final static int DELAY = 500; // retardo del timer, cada cuánto
											// genera un evento ActionEvent
	private final static int POS_X = ANCHO / 3; // posición x del contador
	private final static int POS_Y = ALTO / 3; // posición y del contador
	private int x;
	private int y;
	private int contador;
	private Timer timer;
	
	//Variable para mostrar un mensaje inicial y un mensaje en el metodo mouseClicked
	private String mensaje;
	
	//Variable que sirve para detectar cuando contador esta en 0 o contador llega a 10 
	//y si es true sumara 1 a contador y si es false restara
	private boolean subir=true;


	/**
	 * Constructor
	 */
	public PanelContador()
	{
		this.setBackground(Color.black);
		this.setPreferredSize(new Dimension(ANCHO, ALTO));
		x = POS_X;
		y = POS_Y;
		contador = 0;
		//
		
		this.timer= new Timer(DELAY,this);
		
		mensaje = "Click para iniciar /continuar"; //Mensaje inicial
		this.addMouseListener(this);
		
		
	}

	/**
     *   
     *       
     */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g); //hay que llamar a la superclase
		// 
		
		this.requestFocus();//hace que el foco este sobre el panel

		g.setColor(Color.white); //Color del texto inicial-mensaje
		g.setFont(new Font("Verdana", Font.PLAIN, 10));//Fuente del texto inicial
		g.drawString(mensaje, 20,10); //Coordenadas donde se situa el mensaje inicial
					
		g.setColor(Color.white); //Color del contador
		g.setFont(new Font("Verdana", Font.PLAIN, 30)); //Fuente del contador
		g.drawString(""+contador,150,120); //Coordenadas donde situamos el contador	


	}

	public void mousePressed(MouseEvent e)
	{
	};

	public void mouseReleased(MouseEvent e)
	{
	};

	public void mouseClicked(MouseEvent e)
	{
		// 
		
		if (timer.isRunning())//detecta si esta iniciado o no 
		{
			timer.stop();
			mensaje = "Click con el raton para iniciar la animacion";
		}
		else
		{
			timer.start();
			mensaje = "Click con el raton para parar la animacion";
		}
		repaint();//Como ha cambiado el mensaje tenemos que volver a pintar
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		//Subir se inicializa a true
		if(contador==0)
			{
				subir=true;
				contador++;
			}
			
		if(contador==10)
			{
				subir=false;
				contador--;
			}
			
		if (subir==true )
			{			
				contador++;
			}
		else
			{
				contador--;		
			}
				
		repaint();//volvemos a llamar paintComponent
	};

}
