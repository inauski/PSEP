 
/**
 * Clase AppTexto -  incluye el método main()
 * Arranca la aplicación
 */
public   class AppTexto
{
     
    /**
     * 
     */
    public static void main(String[] args)
    {
         new GuiTexto();
         System.out.println("Fin del hilo main");
    }
}
