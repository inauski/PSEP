
import java.awt.BorderLayout;
import java.awt.Color;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.Timer;
 

public class GuiSemaforo  extends JFrame
{
    private JButton btnIniciarParar;
    
    private PanelSemaforo  panelSemaforo;
    private Semaforo semaforo; // el modelo
    
    
    
    /**
     * Constructor  
     */
    public GuiSemaforo()
    {
        this.semaforo = new Semaforo();
        crearGui();
        mostrarGui();

    }

    /**
     *   
     */
    private void crearGui()
    {
        this.setTitle("Uso de un timer para simular  un semaforo ");
        JPanel pnlSur = new JPanel();
        pnlSur.setBorder(new TitledBorder("Iniciar Semaforo / Parar Semaforo"));

        btnIniciarParar = new JButton("Iniciar");
      
        pnlSur.add(btnIniciarParar);
        this.add(pnlSur, BorderLayout.SOUTH);

        panelSemaforo = new PanelSemaforo();
        this.add(panelSemaforo, BorderLayout.CENTER);
        btnIniciarParar.addActionListener(panelSemaforo);

        

    }

    /**
     *   
     */
    private void mostrarGui()
    {

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(400, 400);
        this.setLocationRelativeTo(null);
        this.setResizable(true);
        this.setVisible(true);
    }

    /**
     * el panel es una clase interna
     */

    private class PanelSemaforo extends JPanel  implements ActionListener

    {
        private final int DELAY = 400;
        private Timer timer; 
    
        /**
         * Constructor 
         */
        public PanelSemaforo()
        {
        	// a completar
            setBackground(Color.black);         	
            this.timer = new Timer(DELAY, this); 
          
    	
    		
    		
            
        }
        /**
         *  
         * Se ejecuta cada vez que el panel necesita ser dibujado
         *      
         */
        public void paintComponent(Graphics g)
        {
           
            // a completar            
           		
    		super.paintComponent(g);//hay que llamar a la superclase
    		
    		g.setColor(semaforo.getColor()); 
    		
    		if (semaforo.getColor()==Color.red)
    	    { 
    		   g.fillRect(0,0, 400, 100);
    	    }
    	   
    	   if (semaforo.getColor()==Color.yellow)
    	   {    		      
    		   g.fillRect(0,100, 400, 100);
    	   }
    	   
    	   if (semaforo.getColor()==Color.green)
    	   {    		   
    		   g.fillRect(0,200, 400, 100);
    	   }
    	   
		
 	
        }
     
     
        /**
         *  este metodo se ejecutara cuando el timer genere un evento y cuando se haga
         *  click en el boton de inicio y en el de parada
         */
        public void actionPerformed(ActionEvent ev)
		{
        	// a completar
        	
        	if(ev.getSource()==timer)
        	{
        		semaforo.avanzar();
        	}
        	
        	else
        	{
        		if(timer.isRunning())//detecta si esta iniciado o no 
        			{
        				timer.stop();
        				btnIniciarParar.setText("Iniciar");
        			}
        		else
		    		{
		    			timer.start();
		    			//semaforo.avanzar();
		    			btnIniciarParar.setText("Parar");
		    		}
        	}
    		repaint();//como cambia el mensaje tenemos que volver a pintar
        	
        }
			
	}
        
		
		
        

    
    
    public static void main(String[] args)
    {
        new GuiSemaforo();
 
    }
}