

import java.awt.Color;

/**
 * Modela un Semaforo  
 *  
 */
public class Semaforo
{

    private Color c;

    /**
     * Constructor de la clase Semaforo
     */
    public Semaforo()
    {
        c = Color.red;
    }

    /**
     *  
     * Obtener el color del semaforo
     */
    public Color getColor()
    {
        return c;
    }

    /**
     * 
     *  Actualizar color del semaforo
     */
    public void avanzar()
    {
    	 if (c==Color.red)
 		 {
    		 c=Color.green;
 		 }
 
    	else if (c==Color.yellow)
		{
    		c=Color.red;
		}
    	else if (c==Color.green)
		{
     		c=Color.yellow;
		}
	
    	
    	
    	

    }
 

    /**
     * 
     *  Cambiar el color   
     */
    public void setColor(Color c)
    {
        this.c = c;
    }
    
    /**
     *   
     */
    public String toString()
    {
        return c.toString();
    }
    
}
