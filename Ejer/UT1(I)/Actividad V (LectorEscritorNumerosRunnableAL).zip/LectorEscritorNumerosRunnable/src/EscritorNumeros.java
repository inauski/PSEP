import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

/**
 *  Tarea que implementa Runnable - escribe   numeros aleatorios (entre 1 y 100)
 *  en el fichero de texto "salida.txt", un n� en cada linea
 *  
 */
public class EscritorNumeros implements Runnable
{

    /**
     * Constructor  
     */
    public EscritorNumeros()
    {

    }

    /**
     *    La tarea que se ejecuta de forma concurrente
     *    Se capturan las excepciones de entrada salida 
     *     Despues de escribir un n�  el hilo duerme 300 milisegundos
     *     
     *    Al terminar muestra un mensaje indicando el final del hilo
     */
    public void run()
    {
    	Random rd = new Random();
		try 
		{
			FileWriter fr = new FileWriter("resultado.txt");
			PrintWriter wr = new PrintWriter(fr);
			for (int i = 1; i <= 10; i++) 
			{
				wr.println("Numero escrito: " + (rd.nextInt(99) + 1));
				Thread.sleep(300);
			}
			fr.close();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}       
    }
}
