

/**
 * 
 * 
 * @author  
 * @version  
 */
public class TestLectorEscritor
{

    /**
     *  Lanza a ejecucion los dos hilos y muestra el mensaje de final del hilo main
     *  
     */
    public static void main(String[] args)
    {
    	Thread hiloEscritor = new Thread(new EscritorNumeros());
    	hiloEscritor.start();
        
        Thread hiloLector = new Thread(new LectorNumeros("numeros.txt"));
        hiloLector.start();
		
        
        
        
    }
}
