import java.io.BufferedReader;
import java.io.FileReader;

/**
 *  Tarea que implementa Runnable para leer numeros enteros desde un
 *  fichero  de texto cuyo nombre se pasa al constructor
 *  Cada linea del fichero contiene un solo numero.
 *  
 *  Al terminar muestra el total de numeros  leidos y su suma
 *  
 *  Lee el fichero con BufferedReader ...
 */
public class LectorNumeros implements Runnable 
{

    private String nombre;  // el nombre del fichero

    /**
     * Constructor  
     */
    public LectorNumeros(String nombre)
    {
        this.nombre = nombre;
    }

    /**
     *    La tarea que se ejecuta de forma concurrente
     *    Se capturan las excepciones de entrada salida y las de conversion de formato
     *    Al terminar muestra un mensaje indicando el final del hilo
     *    Despues de tratar un nº y antes de leer el siguiente el hilo duerme 300 milisegundos
     */
    public void run()
    {
       int suma = 0;
       int cont = 0;
       try(BufferedReader br = new BufferedReader(new FileReader(nombre)))
       {
    	   String line;
    	   while ((line = br.readLine())!= null)
    	   {
    		   suma += Integer.parseInt(line);
    		   cont++;
    		   System.out.println("Numero leido: " + line);
    		   Thread.sleep(300);
    	   }
    	   br.close();
       }
       catch (Exception e)
       {}
       System.out.println("Total de numeros leidos: " + cont + ". Suma: " + suma);
       System.out.println("Fin de hilo " + Thread.currentThread());
       
    	   	
        
        
        
        
        
        
    }
}
