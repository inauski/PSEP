import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Tarea que cuenta las palabras que hay en el fichero de texto xuyo nobre se pasa como parámetro
 * al constructor
 */
public class ContadorPalabras  implements Runnable
{
    private String nombreFichero;

    /**
     *  @param nombreFichero  el nombre del fichero a contar
     */
    public ContadorPalabras(String nombreFichero)
    {
        this.nombreFichero = nombreFichero;
        Thread hilo = new Thread(this);
        hilo.start();
    }

    /**
     * tarea que se ejecuta de forma concurrente
     * La lectura del fichero se hace con Scanner
     * Al terminar el hilo se muestra el nombre del fichero y  total de palabras contadas
     */
    public void run()
    {
    	Thread t = Thread.currentThread();
    	try
    	{
    		int cont = 0;
    		Scanner s = new Scanner(new File(nombreFichero));
    		while (s.hasNext())
    		{
    			cont++;
    			s.next();
    		}
    		System.out.println("El hilo" + t.getName() + " ha leido " + cont + " palabras del archivo " + nombreFichero);
    		s.close();
    	}
    	catch (FileNotFoundException e)
    	{
    		System.err.println("Error en hilo: " + t.getName() + " . No se ha encontrado el archivo especificado.");
    	}
    }
    }
    

