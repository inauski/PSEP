 /**
  * Se crean objetos ContadorPalabras para contar las palabras en un fichero
  * Un hilo por cada fichero 
  * 
  * Lanza tres hilos de ejecucion para contar las palabars de 3 ficheros de texto
  * recorre los argumentos del main con un for
  * 
  * Ej - java ContadorPalabras fichero1.txt fichero2.txt  fichero3.txt
   */
public class TestContadorPalabras
{
  
   public static void main(String args[])
   {
	   for (int i = 0; i < args.length; i++)
	      {
	    	  new ContadorPalabras(args[i]);
	      }  
      
   }
}

