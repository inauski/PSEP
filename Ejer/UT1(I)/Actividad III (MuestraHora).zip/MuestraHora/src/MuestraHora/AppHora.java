package MuestraHora;

public class AppHora 
{
	public static void main(String[] args)
	{
		Thread hiloHora1 = new HiloHora();
		Thread hiloHora2 = new HiloHora();
		Thread hiloHora3 = new HiloHora();
		Thread hiloHora4 = new HiloHora();
		Thread hiloHora5 = new HiloHora();
		Thread hiloHora6 = new HiloHora();
		Thread hiloHora7 = new HiloHora();
		Thread hiloHora8 = new HiloHora();
		Thread hiloHora9 = new HiloHora();
		Thread hiloHora10 = new HiloHora();
		
		hiloHora1.start();
		hiloHora2.start();
		hiloHora3.start();
		hiloHora4.start();
		hiloHora5.start();
		hiloHora6.start();
		hiloHora7.start();
		hiloHora8.start();
		hiloHora9.start();
		hiloHora10.start();
	}
}
