package MuestraHora;
import java.time.LocalTime;


public class HiloHora extends Thread
{
	public HiloHora()
	{
		super();
	}
	
	public void run()
	{
		
		for (int i = 0; i <= 10; i++)
		{
			System.out.println("Mensaje N�: " + i + ", Hilo: " + currentThread() + " , Hora Actual: " + LocalTime.now() );
			try 
			{
				HiloHora.sleep(1000);
			} 
			catch (InterruptedException e) 
			{
				
			}
			
		}
		
	}
}
