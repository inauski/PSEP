package contador;

public class ContadorAscendente2 implements Runnable
{
    public void run()
    {
    	Thread t = Thread.currentThread(); 
    	for(int i = 0; i<10; i++)
		{
    		System.out.println("Hilo: "+ t.getName() + " Contador: "+ i);
		}
    }
}
