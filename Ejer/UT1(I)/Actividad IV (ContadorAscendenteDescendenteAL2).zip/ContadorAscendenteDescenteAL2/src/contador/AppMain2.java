package contador;

public class AppMain2 
{
	 public static void main(String[] args)
	    {
	    	Thread hiloAsc = new Thread(new ContadorAscendente2());
			Thread hiloDesc = new Thread(new ContadorDescendente2());
			
			hiloAsc.start();
			hiloDesc.start();
	    }
}
