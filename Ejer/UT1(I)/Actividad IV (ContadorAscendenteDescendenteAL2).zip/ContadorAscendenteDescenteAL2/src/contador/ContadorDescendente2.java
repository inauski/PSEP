package contador;

public class ContadorDescendente2 implements Runnable
{
    public void run()
    {
    	Thread t = Thread.currentThread();
    	for(int i = 9; i >= 0; i--)
		{
    		System.out.println("Hilo: "+ t.getName() + " Contador: "+ i);
		}
    }
}
