/**
 * Hilo simple con una clase anonima
 */
public class EjemploHiloAnonima 
{
    public static void main(String[] args)
    {
        // crea el hilo como clase anonima - dentro del metodo run() el hilo 
        // escribe diez numeros en la misma linea y luego muestra las propiedades del hilo
        //  nombre del hilo, prioridad, id del hilo, estado, si esta vivo, si es un demonio
         // a completar
    	
    class SegundoHilo implements Runnable{
    	
   //Metodo run que muestra numeros del 1 al 10 y muestra informaci�n del hilo
    public void run(){
    	System.out.println("Numeros del 1 al 10");
       for (int i = 1; i <= 10; i++){
       System.out.print(i + " ");   	//escribe 10 numeros		
       }
       
      
       
    Thread hilo = Thread.currentThread(); //creamos hilo
    
    
    //Mostramos el nombre
    System.out.println("Nombre del hilo: " + hilo.getName());
    
    //Mostramos la prioridad
    System.out.println("Prioridad: " + hilo.getPriority());
    
    //Mostramos el ID
    System.out.println("ID del hilo: " + hilo.getId());
    
    //Mostramos el estado
    System.out.println("Estado: " + hilo.getState());
    
    //Mostramos si est� vivo o no
    if (hilo.isAlive())
    	System.out.println("El hilo est� vivo");
    else
    	System.out.println(("El hilo NO est� vivo"));
    
    //Mostramos si es demonio
    if (hilo.isDaemon())
    	System.out.println("El hilo es un demonio");
    else
    	System.out.println("El hilo NO es un demonio");
    
    } 
    	
}   
    // Ahora vamos  a escribir las propiedades del main
    // nombre del hilo, prioridad, id del hilo, estado, si esta vivo, si es un demonio
    
        
    Thread segundoHilo = new Thread(new SegundoHilo() );
    
    //Mostramos datos del main
    Thread hilo = Thread.currentThread();
    System.out.println("Propiedades del hilo main.");
    System.out.println("Nombre: " + hilo.getName());
    System.out.println("Prioridad: " + hilo.getPriority());
    System.out.println("Id del hilo: " + hilo.getId());
    System.out.println("Estado: " + hilo.getState());
    System.out.println("Esta vivo? : " + hilo.isAlive());
    System.out.println("Es demonio? : " + hilo.isDaemon());
    
    
            
    //Indica si esta activo o no el segundo hilo
        if(!segundoHilo.isAlive())
        {
            System.out.println("Segundo hilo todavia no vivo.");
        }
        // Ahora inicia segundoHilo
        
        segundoHilo.start();
        
      
        if(segundoHilo.isAlive())
        {
            System.out.println("Segundo hilo ahora vivo.");
        }
        
        // Ceder control al segundo hilo
        Thread.yield();
        if(!segundoHilo.isAlive())
        {
            System.out.println("Segundo hilo ya no esta vivo.");
        }
            
        System.out.println("FIN del hilo MAIN");
    }

	
}

