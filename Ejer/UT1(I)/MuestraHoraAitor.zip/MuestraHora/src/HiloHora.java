import java.lang.Thread;
import java.util.Date;
import java.text.SimpleDateFormat;

public class HiloHora extends Thread {
	SimpleDateFormat formato;
	Date fecha;
	
	public HiloHora()
	{
		formato = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		fecha = new Date();
	}
	
	public void run()
	{
		for (int i = 1;i <= 5;i++)
		{
			System.out.println("Mensaje n�: "+i+
					" \nNombre del hilo: "+currentThread()
					 +"\nFecha: "+formato.format(fecha));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
