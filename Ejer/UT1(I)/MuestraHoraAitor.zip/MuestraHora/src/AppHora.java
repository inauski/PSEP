import java.lang.Thread;

public class AppHora {

	public static void main(String[] args) {
		Thread h1 = new HiloHora();
		Thread h2 = new HiloHora();
		Thread h3 = new HiloHora();
		Thread h4 = new HiloHora();
		Thread h5 = new HiloHora();
		Thread h6 = new HiloHora();
		Thread h7 = new HiloHora();
		Thread h8 = new HiloHora();
		Thread h9 = new HiloHora();
		Thread h10 = new HiloHora();
		h1.start();
		h2.start();
		h3.start();
		h4.start();
		h5.start();
		h6.start();
		h7.start();
		h8.start();
		h9.start();
		h10.start();
		System.out.println("Fin del hilo main()");

	}

}
