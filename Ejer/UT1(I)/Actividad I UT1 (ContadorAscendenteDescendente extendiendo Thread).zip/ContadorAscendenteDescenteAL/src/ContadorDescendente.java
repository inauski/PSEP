
/**
 *  Hilo que cuenta hacia abajo  
 */
public class ContadorDescendente extends Thread
{
    private int desde;

    /**
     * Constructor  
     * @param desde inicio de la cuenta
     */
    public ContadorDescendente(int desde)
    {
        super("descendente");
        this.desde = desde;
    }

    /**
     *  
     *  Código a ejecutar por el hilo
     *  Cuenta de forma descendente  y escribe cada valor del contador junto con el nombre del hilo
     * 
     */
    public void run()
    {
    	for(int i = desde; i >= 0; i--)
		{
    		System.out.println("Hilo: "+ this.getName() + " Contador: "+ i);
		}
    }
}
