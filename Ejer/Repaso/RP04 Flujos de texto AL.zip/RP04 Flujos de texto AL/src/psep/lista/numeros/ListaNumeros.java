package psep.lista.numeros;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.BufferedWriter;
 
import java.io.IOException;
/**
 *  La clase guarda en una colecci�n ArrayList una
 *  lista de n�meros enteros
 *  
 */
public class ListaNumeros
{
    // define la colecci�n
    private ArrayList<Integer> lista;

    /**
     * Constructor  - instancia la colecci�n
     */
    public ListaNumeros()
    {
        lista = new ArrayList<Integer>();
    }

    /**
     *  a�ade un n�mero a la colecci�n
     */
    public void add(int numero)
    {
        lista.add(numero);
    }

    /**
     * borrar todos los elementos de la lista, dejadla vac�a
     */
    public void borrarLista()
    {
        lista.clear();
    }

    /**
     *  Crea un fichero de texto  cuyo nombre se
     *  pasa como argumento
     *  Para crear el fichero recorreremos la colecci�n y
     *  guardaremos cada n�mero de la lista en el fichero 
     *  
     *  
     *  
     *  Captura las excepciones que se puedan producir
     */
    public void salvarEnFicheroDeTexto(String nombre) 
    {
        try
        {
            File f = new File(nombre);
            PrintWriter salida = new PrintWriter(new BufferedWriter(new FileWriter(f)));
            // a completar
            int i = 1;
            String s = ":";
            for (Integer n: lista) {
            	if (lista.size() == i)
            		s = "";
				salida.write(n + s);
				i++;
			}
            salida.close();
            
        }
        catch (IOException e)
        {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

    }
    
    /**
     * Parsea la l�nea recibida extrayendo cada palabra y a�adi�ndola a la lista
     * @param linea
     */
    private  void parsearLinea(String linea)
	{
		String[] palabras = linea.split(":");
		// a completar // DOIT
		for(String p:palabras){
			lista.add(Integer.parseInt(p));
		}
			
	}

    /**
     *  lee de un fichero de texto cuyo nombre se pasa
     *  como argumento una serie de n�meros enteros y cada n�mero lo guarda en la lista
     *  Se usa la clase BufferedReader
     *  Al acabar se cierra el fichero
     *  
     *   
     *  
     *  Captura las excepciones que se puedan producir
     */
    public void leerFicheroDeTextoConBufferedReader(String nombre)  
    {
         
        try
        {
            File f = new File(nombre);
            if( f.exists() ) {
            	
            	BufferedReader entrada = new BufferedReader(new FileReader(f));
	            // a completar  // DOIT          
	            String linea;        
	            while((linea = entrada.readLine())!=null) {
	            	parsearLinea(linea);
	            }
	            entrada.close();
            } else {
            	System.out.println("El fichero \"" + f.getName() + "\" no existe.");
            }

        }
        catch (IOException e)
        {
             e.printStackTrace();       
        }
    }
    
    /**
     *  lee de un fichero de texto cuyo nombre se pasa
     *  como argumento una serie de n�meros enteros y cada n�mero lo guarda en la lista.
     *  Se usa la clase Scanner
     *  Al acabar se cierra el fichero
     *  
     *   
     *  
     *  Captura las excepciones que se puedan producir
     */
    public void leerFicheroDeTextoConScanner(String nombre)  
    {
         
        try
        {
            File f = new File(nombre);
            if (f.exists() ) {
            	@SuppressWarnings("resource")
				Scanner entrada = new Scanner(f);
	            
	            while(entrada.hasNext()){
	            	parsearLinea(entrada.next());
	            }
	            entrada.close();
            } else {
            	System.out.println("El fichero \"" + f.getName() + "\" no existe.");
            }
            
        }
        catch (IOException e)
        {
             e.printStackTrace();           
        }
    }
    
    
    /**
     * Representaci�n textual de la colecci�n
     */
    public String toString()
    {
        StringBuilder sb = new StringBuilder("Lista:  ");
        for (Integer n : lista)
        {
            sb.append(n + " ");
        }
        return sb.toString();
    }

    /**
     * Muestra la lista en pantalla
     */
    public void mostrarLista()
    {
        System.out.println(this.toString());
    }

}
