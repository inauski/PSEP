package psep.lista.palabras;

/**
 *  Esta clase nos servir� para probar 
 *  los m�todos de la clase ListaPalabras
 */
public class AppListaPalabras
{

    /**
     *  
     *  
     */
    public static void main(String[] args)
    {
        // define y crea un objeto lista
        ListaPalabras lista = new ListaPalabras();
        
        
        // lee desde el fichero de texto la lista y la muestra en pantalla
        lista.borrarLista();
        lista.leerFicheroDeTextoConScanner("palabras.txt");
        System.out.println("Lista le�da de fichero texto con Scanner");
        lista.mostrarLista();
        
        lista.borrarLista();
        lista.leerFicheroDeTextoConBufferedReader("palabras.txt");
        System.out.println("Lista le�da de fichero texto con BufferedReader");
        lista.mostrarLista();
        
        // A�ade a la clase ListaPalabras el m�todo public void guardarEnFicheroTexto
        lista.guardarEnFicheroTexto("salida.txt");
    }
}
