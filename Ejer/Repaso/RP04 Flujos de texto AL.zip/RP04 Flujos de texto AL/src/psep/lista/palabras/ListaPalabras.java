package psep.lista.palabras;


import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.BufferedWriter;
 
import java.io.IOException;
/**
 *  La clase guarda en una colecci�n ArrayList una
 *  lista de palabras
 *  
 */
public class ListaPalabras
{
    // define la colecci�n
    private ArrayList<String> lista;

    /**
     * Constructor  - instancia la colecci�n
     */
    public ListaPalabras()
    {
        lista = new ArrayList<String>();
    }

    /**
     *  a�ade un n�mero a la colecci�n
     */
    public void add(String palabra)
    {
        lista.add(palabra);
    }

    /**
     * borrar todos los elementos de la lista, dejadla vac�a
     */
    public void borrarLista()
    {
        lista.clear();
    }

    

    /**
     *  lee de un fichero de texto cuyo nombre se pasa
     *  como argumento una serie de palabras
     *  Usa como ayuda el m�todo parsearLinea()   
     *  
     *  Captura las excepciones que se puedan producir
     */
    public void leerFicheroDeTextoConScanner(String nombre)  
    {
         
        try
        {
            File f = new File(nombre);
            // a completar // DOIT
            if( f.exists() ) {
            	
            	Scanner sc = new Scanner(f);
            	
                while(sc.hasNext()){
                	parsearLinea(sc.next());
                }  
                
                sc.close();
                
            } else {
            	System.out.println("El fichero \"" + f.getName() + "\" no existe.");
            	System.exit(0);
            }
                        
        }
        catch (IOException e)
        {
             e.printStackTrace();

        }
    }
    
    /**
     * Parsea la l�nea recibida extrayendo cada palabra y a�adi�ndola a la lista
     * @param linea
     */
    private  void parsearLinea(String linea)
	{
		String[] palabras = linea.split(":");
		// a completar // DOIT
		for(String p:palabras){
			lista.add(p);
		}
			
	}
    

    /**
     *  lee de un fichero de texto cuyo nombre se pasa
     *  como argumento una serie de palabras y las a�ade a la lista
     *  Usa como ayuda el m�todo parsearLinea()     *   
     *  
     *  Captura las excepciones que se puedan producir
     */
    public void leerFicheroDeTextoConBufferedReader(String nombre)  
    {
         
        try
        {
            File f = new File(nombre);
            // a completar // DOIT
            String linea;
            if( f.exists() ){
            	
            	BufferedReader br = new BufferedReader(new FileReader(f));
                
                while((linea = br.readLine())!=null) {
                	parsearLinea(linea);
                }
                
                br.close();
                
            }  else {
            	
            	System.out.println("El fichero \"" + f.getName() + "\" no existe.");
            	System.exit(0);
            	
            }

        }
        catch (IOException e)
        {
             e.printStackTrace();
           

        }
    }
    
    /**
     * Representaci�n textual de la colecci�n
     */
    public String toString()
    {
        StringBuilder sb = new StringBuilder("Lista: ");
        for (String palabra : lista)
        {
            sb.append(palabra + " ");
        }
        return sb.append("\n").toString();
    }

    /**
     * Muestra la lista en pantalla
     */
    public void mostrarLista()
    {
        System.out.println(this.toString());
    }
    
    /**
     * A�ade a la clase ListaPalabras el m�todo public void guardarEnFicheroTexto(String nombre),
     *  que guarda en el fichero cuyo nombre se pasa como par�metro la siguiente informaci�n:
     *  
     *  LISTA DE PALABRAS
     *  1.esto
     *  2.es
     *  3.un
     *  4.ejemplo
     *  5.de
     *  6.uso
     *  7.de
     *  8.flujos
     *  9.de
     *  10.texto
     *  Total palabras: 10
     *  	
     * @param nombre
     */
    
    public void guardarEnFicheroTexto(String nombre){

            try {
                File f = new File(nombre);
                String frase = "esto es un ejemplo de uso de flujos de texto";
                String [] palabras = frase.split(" "); 
                PrintWriter salida = new PrintWriter(new BufferedWriter(new FileWriter(f)));
                salida.write("LISTA DE PALABRAS\n");
                int i = 1;
                for (String p: palabras) {
    				salida.write(i + "." + p + "\n");
    				i++;
    			}
                salida.write("Total palabras: " + palabras.length);
                salida.close();
                System.out.println("Fichero \"" + f.getName() + "\" generado.");
                
            }
            catch (IOException e)
            {
                e.printStackTrace();
                System.out.println(e.getMessage());
            }

    }

}
