
/**
 * 2 Hilos, uno escribe  pares desde el 2 hasta el 20 y
 * otro escribe 20 veces el mensaje "Ejemplo con join()"
 *  
 */
public class ParMensaje extends Thread
{

    /**
     *  
     *  
     */
    public static void main(String[] args) throws InterruptedException
    {
    	// crear un hilo que implemente Runnable con clase anónima que escriba los
        // pares entre 2 y 20 junto con el nombre del hilo
    	Thread hiloP = new Thread(new Runnable()
        {
        			
        			//metodo run que escribe los pares del 2 al 20 con el nombre del hilo correspondiente
    				//captura las excepciones en caso de que las hubiese.
        			public void run() {
        				System.out.println("Empieza el hilo ");
        				for (int i = 2; i <= 20; i++) {
        					if (i % 2 == 0)
        						System.out.println(Thread.currentThread().getName() + " "+ i);
        				}
        				try 
        				{
        					Thread.sleep(1000); //dormimos el hilo por 1 segundo
        				}
        				catch (InterruptedException ex)
        				{
        					ex.printStackTrace();
        				}
        			}
        } );
        
        
        		
        
        // crear un hilo que implemente Runnable con clase anonima que muestre
        // el mensaje "ejemplo con join()" 10 veces junto con el nombre del hilo 
        Thread hiloM = new Thread(new Runnable()
        { 
        
        				//metodo run que escribe 'ejemplo con join' 10 veces y el nombre del hilo
        				//captura las excepciones en caso de que las hubiese.
						public void run() {
						System.out.println("Empieza el hilo join ");
							for (int i = 1; i <= 10; i++) {
        						System.out.println("Ejemplo con join " + Thread.currentThread().getName()  );
							}
							try 
	        				{
	        					Thread.sleep(1000); //Dormimos el hilo por 1 segundo
	        				}
	        				catch (InterruptedException ex)
	        				{
	        					ex.printStackTrace();
	        				}
						}
        } );
        
						
               
        
       
        // iniciar hilos
        hiloP.start();
        hiloM.start();
        
        
        // hacer que el hilo main espere a que los dos hilos anteriores terminen
        
        ParMensaje p = new ParMensaje();
        p.join(); //pausamos la ejecucion para esperar a que los otros hilos terminen.
        System.out.println("Aqui acaba el hilo main() "); 
    }
}
