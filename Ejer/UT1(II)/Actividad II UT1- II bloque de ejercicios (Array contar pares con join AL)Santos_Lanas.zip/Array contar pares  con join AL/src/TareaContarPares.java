
/**
 *  Esta tarea cuenta los valores pares en un array
 */
public class TareaContarPares implements Runnable
{
    private int[] array;
    private int desde;
    private int hasta;
    private int pares; // la cantidad de pares que se han contado

    /**
     * Constructor  
     * @param array el array que contiene los numeros
     * @param desde posicion del array desde la que se van a contar pares
     * @param hasta posicion del array hasta la que se van a contar pares (exclusive)
     */
    public TareaContarPares(int[] array, int desde, int hasta)
    {
        pares = 0;
        this.array = array;
        this.desde = desde;
        this.hasta = hasta;
    }

    /**
     *  devuelve la cantidad de pares 
     * 
     */
    public int getPares()
    {
        return pares;
    }

    /**
     * contar los pares. En cada iteracion el hilo duerme 500 msg
     * Al final se escribe un mensaje indicando el nombre del hilo y su
     * finalizacion
     * 
     */
    public void run()
    {
    	//Bucle que calcula los pares y duerme el hilo durante 5 seg. Si existe un error de interrupcion, lo captura.
    	for (int i=desde;i<hasta;i++) {
    		if (array[i] % 2 ==0)
    			pares++;
    		try
    		{
    			Thread.sleep(500);
    		}
    		catch (InterruptedException e) 
    		{
    			e.printStackTrace();
    		}
    	
    	}
    	
    	System.out.println("Fin del hilo" + Thread.currentThread().getName());
    	
    	
    }
}
