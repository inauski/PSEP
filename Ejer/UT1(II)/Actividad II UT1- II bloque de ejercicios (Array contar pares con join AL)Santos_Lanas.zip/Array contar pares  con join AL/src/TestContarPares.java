
/**
 *  Se van a utilizar 3 hilos para contar los
 *  valores pares que hay en un array de un determinado tama�o
 *  Cada hilo cuenta los pares en una parte del array. Cuando
 *  los tres hilos terminan se muestra el total de pares que habia en al array inicial
 *  
 */
public class TestContarPares
{ 
    public static void main(String[] args) throws InterruptedException
    {
        final int MAX = 15; // el tama�o del array
        int[] array = new int[MAX];
        
        // inicializar el array con valores aleatorios entre 1 y 20 con Math.random()
        for(int i=0;i<array.length;i++)
        	array[i] = (int) (Math.random()*19+1);
        
        
        // escribir el array inicial
        System.out.println("Array inicial");
        for (int i =0;i<array.length;i++)
        	System.out.print(array[i]+ " ");
        System.out.println();
        
        
        // crear e iniciar los tres hilos
        
        //Cada tarea trata una tercera parte del array
        TareaContarPares tarea1= new TareaContarPares(array, 0,4 );  
        TareaContarPares tarea2= new TareaContarPares(array, 5,9 );  
        TareaContarPares tarea3= new TareaContarPares(array, 10,14 );  
       
        
        Thread hilo1 = new Thread( tarea1);         
        Thread hilo2 = new Thread( tarea2);         
        Thread hilo3 = new Thread( tarea3); 
       
        //inicio de los hilos
        hilo1.start();  
        hilo2.start(); 
        hilo3.start(); 
        
        
        // hacer que el hilo main esepre a que terminen los hilos anteriores
        
        hilo1.join(); 
        hilo2.join(); 
        hilo3.join(); 
        
        //Imprime el total de pares
        System.out.println("Total pares :" +(tarea1.getPares()+tarea2.getPares()+tarea3.getPares()));
        
    }
}
