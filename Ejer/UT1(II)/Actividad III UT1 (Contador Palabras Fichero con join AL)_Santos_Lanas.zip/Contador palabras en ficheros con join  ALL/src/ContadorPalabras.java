import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

 
public class ContadorPalabras extends Thread
{
     private String nombreFichero;
     private int totalPalabras;  // el total de palabras contadas
     
   /**
    *  @param nombreFichero  el nombre del fichero del que contar
   */
   public ContadorPalabras(String nombreFichero)
   {
      this.nombreFichero = nombreFichero;
      totalPalabras = 0;
     
   }

   /**
    * se cuentan las palabras del fichero con Scanner
    */
   public void run()
   {
       
	   try
   	{
   		
   		Scanner s = new Scanner(new File(nombreFichero));
   		while (s.hasNext())
   		{
   			s.next();
   			totalPalabras++;
   		}
   		
   		s.close();
   	}
   	catch (FileNotFoundException e)
   	{
   		System.out.println("Error en hilo: " + Thread.currentThread().getName() + " . No se ha encontrado el archivo especificado.");
   	}
    		 
	   System.out.println("Fin del hilo: "+Thread.currentThread().getName()+ " Palabras en el fichero "+ nombreFichero +" : " + getTotalPalabras());
	   
   }

   /**
    * acesor para el total de palabras contadas
    */
   public int getTotalPalabras()
   {
       return totalPalabras;
   }
}
