
/**
 * Se crean objetos ContadorPalabras para contar las palabras en un fichero
 * Un hilo por cada fichero 
 * Despues de que finaliza el ultimo hilo  se escribe el total de palabras entre todos los ficheros
 * 
 *Ej - java TestContadorPalabras fichero1.txt fichero2.txt  fichero3.txt
 */
public class TestContadorPalabras
{

    public static void main(String args[])
    {
    	
    	
        // comprobar que el n� de argumentos es correcto

    	if (args.length > 3) { //si hay m�s de 3 par�metros
            System.out.println("Hay demasiados par�metros.");
            return;
        } 
    	else if (args.length < 1) { //si no hay par�metros      
            System.out.println("No ha escrito parametros");
            return;
    	}
    	
      
    	
        
        // definir un array de tipo ContadorPalabras con tantos elementos como nombres de fichero se hayan pasado
        //En este caso son 3 ficheros.
    	ContadorPalabras[] cp = new ContadorPalabras[3];
    	
    	
        
        // con un bucle recoger los nombres de ficheros desde linea de comandos y crear e
        // iniciar los hilos
        
    	for(int i = 0;i < cp.length;i++)
    	{
    		cp[i] = new ContadorPalabras(args[i]); 
    		cp[i].start(); 
    	}
    	
    	
    	
    	
        
        // con un bucle recorre el array de hilos anterior e indicar que
        // el main espere a que todos acaben
        //Al array de hilos lo hemos nombrado como cp
    	for(ContadorPalabras i:cp)
    	{
    		try {
				i.join(); //espera a que todos acaben
			} 
    		catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
        
        
        // con un bucle calcular el total de palabras contadas entre todos los hilos
        
    	
    	int totalPal = 0; //iniciamos un contador de palabras totales, recorremos el array y devolvemos el total de palabras
    	for (ContadorPalabras j: cp)
    	{
    	    totalPal += j.getTotalPalabras();
    	}
    	
	    System.out.println("Total de palabras entre todos los ficheros: "+ totalPal);
    	
    	
    	
    	
    	
    }
}
