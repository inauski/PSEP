import java.util.Random;
 

/**
   
   El programa ejecuta dos hilos que depositan dinero en la misma cuenta 
   bancaria
*/
public class TestCuenta 
{
   
   public static void main(String[] args)
   {
	   //Creamos una cuenta bancaria
       CuentaBancaria cb = new CuentaBancaria();
       
       //Creamos dos hilos con los que ingresaremos en la cuenta. Despu�s los iniciamoss
       Thread th1 = new TareaDeposito(cb,  100);
       Thread th2 = new TareaDeposito(cb,  100);
       th1.start(); 
       th2.start();
	   
	   
	   
        
   }
}

