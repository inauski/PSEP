/**
 *  Una tarea que hace depositos periodicos en la cuenta
 *  despues de cada ingreso el hilo duerme TIEMPO
 */
class TareaDeposito  extends Thread
{
    private CuentaBancaria cuenta;
    private double cantidad;

    private static final int INGRESOS = 10;  // n� ingresos que hace el hilo
    private static final int TIEMPO = 1000;  // tiempo que dormira el hilo

    /**
     * @param cuenta La cuenta bancaria
     * @param cantidad La cantidad a ingresar
     */
    public TareaDeposito(CuentaBancaria cuenta, double cantidad)
    {
         this.cuenta = cuenta;
         this.cantidad = cantidad;
    	
    	
    }

    public void run()
    {
    	try
    	{
    		//Recorremos el bucle para depositar una cantidad en la cuenta
    		for (int i=1; i <= INGRESOS; i++){
    			cuenta.depositar(cantidad);	
    		}
    		Thread.sleep(TIEMPO); //Duerme el hilo por 'TIEMPO', que es 1000
    	}
    	
    	catch (InterruptedException ex) //Excepci�n de interrupci�n
		{
			System.out.println(ex.getMessage());
		}
    }

}

 