package psep.hucha;

public class Hucha
{
	private int total;
	
	public Hucha()
	{
		total = 0;
	}
   //Ponemos este y el siguiente metodo como synchronized para que solo un hilo lo ejecute 
	public synchronized  int getTotal()
	{
		return total;
	}

	public synchronized  void add(int valor)
	{
		this.total += valor;
	}
	
	
}
