package psep.hucha;


public class DemoHucha {

	public static void main(String[] args) {
		
		Hucha hucha=new Hucha();
		final int MAX = 100; // el tama�o del array
		Thread [] array = new Thread[MAX]; 

		for (int i=0;i<MAX;i++)//creamos el array de hilos
        {   
        	array[i]=new HiloHucha(hucha);
        }
        
        for (int i=0;i<MAX;i++)//inicializamos los hilos
        {    
        	array[i].start();
        }
        
        for (int i=0;i<MAX;i++)//paramos los hilos
        {
            
        	try
			{
				array[i].join();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
        }
        
        System.out.println("Valor de la hucha :" +hucha.getTotal());
	}

}
