package psep.hucha;
public class HiloHucha extends Thread 
{
	private Hucha hucha;

	/*
	 * Constructor
	 */
	public HiloHucha(Hucha h){
	this.hucha = h;
	}
	
	public void run()
	{	

		try
		{
			for (int i = 1; i <= 100; i++)
			{
				hucha.add(2);
				Thread.sleep(30);
			}
			
		}
		catch (InterruptedException ex)
		{
			System.out.println(ex.getMessage());
		}
	}

}
