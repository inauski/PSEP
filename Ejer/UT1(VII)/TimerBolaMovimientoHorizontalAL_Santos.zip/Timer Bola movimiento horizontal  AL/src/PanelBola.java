import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class PanelBola extends JPanel implements ActionListener
{
	private final static int ANCHO = 400; // ancho del panel
	private final static int ALTO = 300; // alto del panel
	private final static int DELAY = 10; // retardo del timer, cada cuanto se genera un evento Timer 
	private final static int POSX1 = 350; // posici�n x de la l�nea 1 (la
											// vertical)
	private final static int POSY1 = 0; // posici�n y de la l�nea 1 (la
										// vertical)
	private final static int POSX2 = 0; // posici�n x de la l�nea 1 (la
										// horizontal)
	private final static int POSY2 = 250; // posici�n y de la l�nea 1 (la
											// horizontal)
	private final static int DIAMETRO = 30;
	
	private final static int MAXD = POSX1-DIAMETRO; //Posicion maxima en x.
	
	
	private int x = POSX1-DIAMETRO; // coordenada x de la bola
	private int y = POSY2-DIAMETRO; // coordenada y de la bola
	
	private Timer timer;

	private boolean derecha = false; // indica si la bola va hacia la derecha o hacia la
								// izquierda

	/**
	 * Constructor
	 */
	public PanelBola()
	{
		//Color del fondo del panel
		this.setBackground(new Color(0,0,0));
		//Tama�o del panel
		this.setPreferredSize(new Dimension(ANCHO, ALTO));
		this.timer = new Timer(DELAY,this); //Velocidad a la que se mueve la bola
		timer.start();

	}
				

	/**
     *   Es un m�todo que dibuja componentes gr�ficos en el JPanel
     *       
     */
	public void paintComponent(Graphics g)
	{
		// establecer posicion inicial de la bola, crear e iniciar el timer
		// la bola al principio va hacia la derecha
		
		super.paintComponent(g);

		// dibujar la linea vertical y la horizontal en color verde
        g.setColor(Color.green);
		g.drawLine(POSX2, POSY2, POSX1, POSY2); //L�nea horizontal
		g.drawLine(POSX1, POSY2, POSX1, POSY1); //L�nea Vertical
		
		// dibujar la bola de color rojo
		g.setColor(Color.red);
		g.fillOval(x, y, DIAMETRO, DIAMETRO);
		

	}

	/**
	 * se ejecuta cada vez que el timer produce un evento actualizar coordenadas
	 * de la bola y volver a dibujar el panel
	 * 
	 * 
	 */
	public void actionPerformed(ActionEvent ev)
	{

    	  actualizar();	
    	  repaint();

	}

	/**
	 * metodo privado de ayuda que modifica las coordenadas de la bola
	 * dependiendo de si va hacia la derecha o izquierda
	 */
	private void actualizar()
	{
		if (derecha == true)
		{   
			if (x == MAXD) //Limite derecho
			{
				derecha = false; //si llega al limite cambia el sentido
			}
			else
			{
				x++; //Se mueve a la derecha
			}
		}
		else 
		{
			if (x == 0) //Limite izquierdo
			{
				derecha = true; //si llega al limite izquierdo cambia el sentido
			}
			else
			{
				x--; //Se mueve a la izquierda
			}
		}
		

	}

}
