/** 
 * 
 *  
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
 

public class GuiPanelColores extends JFrame
{
    private PanelColor panel;
    
    /**
     * Constructor de la clase GuiPrueba
     */
    public GuiPanelColores()
    {
        crearGui();
        mostrarGui();

    }

    /**
     *   Se crean 16 paneles, cada uno con un color aleatorio
     */
    private void crearGui()
    {
    	String titulo = "Creacion de 16 panels con color  aleatorio  en cada panel - \nCada panel lo ejecuta un hilo";
        this.setTitle(titulo);
        this.setLayout(new GridLayout(4, 4));
        for (int f = 1; f <= 4; f++)
        {
            for (int c = 1; c <= 4; c++)
            {
                this.add(new PanelColor());
            }
        }

    }

    /**
     *   
     */
    private void mostrarGui()
    {

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(400, 400);
        this.setLocationRelativeTo(null);
        this.setResizable(true);
        this.setVisible(true);
    }

    /**
     * Cada panel es una clase interna
     * Sera la tarea Runnable
     */
    private class PanelColor extends JPanel  implements Runnable
    {
        private Thread th;
        private Color color;
        
        private Random aleatorio; //numero aleatorio
        private int num; //variable para devolver los colores

        /**
         * Constructor 
         * crea el hilo de ejecucion y lo inicia
         */
        public PanelColor()
        { 
        	 aleatorio=new Random(); //utilizado para generar los colores aleatoriamente
        	 color = generarColor();
        	
        	 // a completar
        	
        	 
        	 th = new Thread(this); //creamos el hilo y lo iniciamos
        	 th.start();
        }

        /**
         *  
         * Se ejecuta cada vez que el panel necesita ser dibujado
         *      
         */
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);     
            setBackground(color);   
            setBorder(BorderFactory.createLineBorder(Color.black));

        }

        /**
         * ejecutar indefinidamente 
         * se obtienen un color aleatorio para el panel con el metodo generarColor(),
         * se dibuja el panel y se duerme el hilo una cantidad de milisegundos
         */        
        public void run()
        {
        	// a completar
        	while(true)
        	{
        		color=generarColor(); //se obtiene el color del metodo generarColor
    			repaint(); //como hay cambios llamamos a repaint

    			try 
    			{
    				Thread.sleep(100);
    			} catch (InterruptedException e)
    			{
    				e.printStackTrace();
    			}
        	}
        	

        }
        /**
         *  
         * Obtiene un color aleatorio de entre 6 colores
         *      
         */
        private Color generarColor()
        {
            // definir un array colores con 6 colores diferentes
            // devolver un color aleatorio de entre los 6
        	
        	Color  colores[] ={Color.red, Color.blue, Color.green, Color.yellow, Color.white,Color.pink };
        	
        	num=aleatorio.nextInt(6);
       	 	return colores[num]; //devuelve cualquier color del array 'colores', generado aleatoriamente y guardado en 'num'
        }

    }
    
    /**
     * Punto de entrada a la aplicacion
     */
    public  static void main(String[] args)
    {
          SwingUtilities.invokeLater(new Runnable()
                                {
                                     public void run()
                                     {
                                         new GuiPanelColores();
                                     }
                                }
                                );
    }

}