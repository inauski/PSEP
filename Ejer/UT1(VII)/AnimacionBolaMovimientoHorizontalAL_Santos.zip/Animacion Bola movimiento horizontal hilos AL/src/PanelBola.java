import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class PanelBola extends JPanel implements Runnable 
{
	public final static int MILISEGUNDOS = 70; 
	public final static int ANCHO = 400; // ancho del panel
	public final static int ALTO = 300; // alto del panel
	private final static int POSX1 = 350; // posicion x de la linea 1 (la
											// vertical)
	private final static int POSY1 = 0; // posicion y de la linea 1 (la
										// vertical)
	private final static int POSX2 = 0; // posicion x de la linea 1 (la
										// horizontal)
	private final static int POSY2 = 250; // posicion y de la linea 1 (la
											// horizontal)
	public final static int DIAMETRO = 30;
	private int x; // coordenada x de la bola
	private int y; // coordenada y de la bola

	private boolean derecha; // indica si la bola va hacia la derecha o hacia la
								// izquierda
	
	//private final static int MAXD = POSX1-DIAMETRO; //Posicion maxima en x.

	private Thread th;
	
	/**
	 * Constructor - crea el hilo y lo inicia
	 */
	public PanelBola()
	{
		this.setBackground(Color.black);
		
		// establecer tamano del panel
		this.setPreferredSize(new Dimension(ANCHO, ALTO));
		
		// establecer posicion inicial de la bola
		x = 0;
		y = POSY2 - DIAMETRO;
		derecha = true;
		// completar
		
		th = new Thread(this); //crea el hilo y lo inicia
		th.start();
		
		
		 

	}

	/**
     *   Este metodo se ejecuta cada vez que el panel necesita ser dibujado
     *       
     */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		//Dibujar las lineas horizontales y verticales verdes
		g.setColor(Color.green);
		g.drawLine(POSX1, POSY1, POSX1, POSY1 + ALTO); // dibujar linea vertical
		g.drawLine(POSX2, POSY2, POSX2 + ANCHO, POSY2); // dibujar linea horizontal
		
		// dibujar la bola
		g.setColor(Color.red);
		g.fillOval(x, y, DIAMETRO, DIAMETRO);

	}

	/**
     * implementa el bucle de animación
     * Ejecutar indefinidamente: actualizar las coordenadas de la bola, hacer una pausa
     * durmiendo el hilo y volver a dibujar el panel. Usa los métodos privados actualizar() y pausa()
     *   
     */
	public void run()
	{
		 // a completar
		
		while (true)
		{
			//Llamamos a los metodos mientras se cumpla la condicion
			actualizar();
			repaint();
			pausa();
			
			
		}
	}
	
	/**
	 * Dormir el hilo los msg indicados por la constante MILISEGUNDOS
	 */
	private void pausa()
	{
		// a completar
		
		//Duerme el hilo durante los milisegundos(70)
		try {
			Thread.sleep(MILISEGUNDOS);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		
		
	}

	/**
	 * actualizar adecuadamente la posicion de la bola
	 */
	private void actualizar()
	{
		// a completar
		
		if (this.x ==POSX1-DIAMETRO)
			derecha=false;
		
		if (x==POSX2)
		{			
			derecha=true;
		}
			
		if(derecha)
		{
			x += 5;
		}
			
		else
			x -= 5;
		
		

//		if (derecha == true)
//		{   
//			if (x == MAXD) //Limite derecho
//			{
//				derecha = false; //si llega al limite cambia el sentido
//			}
//			else
//			{
//				x++; //Se mueve a la derecha
//			}
//		}
//		else 
//		{
//			if (x == 0) //Limite izquierdo
//			{
//				derecha = true; //si llega al limite izquierdo cambia el sentido
//			}
//			else
//			{
//				x--; //Se mueve a la izquierda
//			}
//		}
		
	}

}
